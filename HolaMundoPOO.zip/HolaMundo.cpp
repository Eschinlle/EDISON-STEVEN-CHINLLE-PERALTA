#include<stdio.h>
#include<iostream>
#include<stdlib.h>

using namespace std;

int main()
{
    system("Color F1");
    cout<<"ACTIVIDAD DE APRENDIZAJE NUMERO 1"<<endl<<endl;
    cout<<"Hola Mundo, PROGRAMACION ORIENTADA A OBJETOS..."<<endl<<endl;
    system("Pause");
    return 0;
}
